/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.saks.imobiliaria.model;

import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

/**
 *
 * @author 7915772
 */
public class Interesse {
    @ManyToOne
    @JoinColumn(name = "id_Imovel")
    private Imovel imovel;
    
    @ManyToOne
    @JoinColumn(name = "id_Cliente")
    private Cliente cliente;
}
